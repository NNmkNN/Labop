package com.company;

public class Main {

    public static void main(String[] args) {
        int x = 7;
        int y = 2;
        System.out.println(x/y);//ділення без остачі
        System.out.println(x%y);//остача
        System.out.println(x+y);//додавання
    }
}
