package com.company;

public class Main {

    public static void main(String[] args) {
	double x = 6.2;
    double y = 3.6;
    System.out.println(Math.round (x));
    System.out.println(Math.round(y));
    }
}
